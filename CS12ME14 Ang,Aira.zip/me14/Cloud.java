package me14;

import java.util.Random;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
public class Cloud extends GameObject{
	BufferedImage cloudImage;

	public Cloud(){
		cloudImage=MarioWindow.getImage("Cloud.gif");
	}
	public void paint(Graphics2D g){
		g.drawImage(cloudImage,100,100,null);
	}
}
