package me14;

import java.awt.Graphics2D;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;

public class Bg extends GameObject{
	BufferedImage bg;

	public Bg(){
		bg=MarioWindow.getImage("bg.jpg");
	}
	public void paint(Graphics2D g){
		g.drawImage(bg,0,0,null);
	}
	
}
