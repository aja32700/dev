package me14;

import java.util.Random;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;

public class Zombie extends GameObject {
	int hp;
	Random r= new Random();
	BufferedImage zombieAliveImage;
	BufferedImage zombieDeadImage;
	
	//ImageIcon coinImage;

	public Zombie(){
		hp=100;
		zombieAliveImage=MarioWindow.getImage("z1.png");
		zombieDeadImage=MarioWindow.getImage("z2.png");
		//coinImage=MarioWindow.getGif("Coin.gif");
		
	}

	public void paint(Graphics2D g){ //Mario window is running independently
		Font text= new Font("Courier New",1,24);
		g.setFont(text);
		
		if (hp>=80) {
			g.setColor(Color.GREEN);	
			g.drawString("hp= " + hp,600,260);
			g.drawImage(zombieAliveImage,600,300,null);
		} else if(hp>=40 && hp<=79){
			g.setColor(Color.YELLOW);
			g.drawString("hp= " + hp,600,260);
			g.drawImage(zombieAliveImage,600,300,null);
		} else if(hp>=39&&hp<=20){
			g.setColor(Color.ORANGE);
			g.drawString("hp= " + hp,600,260);
			g.drawImage(zombieAliveImage,600,300,null);
		} else if (hp>=1&&hp<20){
			g.setColor(Color.RED);
			g.drawString("hp= " + hp,600,260);
			g.drawImage(zombieAliveImage,600,300,null);
		} else if(hp<=0){
			g.drawImage(zombieDeadImage,600,300,null);
		}
		//g.fillArc(320,300,60,60,0,360); //position,positiom,deg
		
	}
	
	public void visualize(){
		System.out.print("[");
		for(int i=0; i<=(hp/10)-1;i++ ){
			System.out.print("*");
		}
		for(int i=0; i<=10-(hp/10)-1;i++){
			System.out.print("-");
		}
		System.out.print("] Zombie hp: " + hp + "\n");
	}	
	
	public void shootMe(){
		hp=hp-10;		
	}
	public int regenerate(){
		int dmg=r.nextInt(20)+1;
		hp=hp+dmg;
		return dmg;
	}
	public boolean grenadeMe(){
		int miss=r.nextInt(100)+1;
		if(miss>20){
			hp=hp-30;
			return true;
		} else{
			return false;
		}
	}
	public boolean decapitate(){
		int miss=r.nextInt(100)+1;
		if(miss<50){
			return true;
		} else {
			return false;
		}
	}
	public void choices(){
		System.out.println("\nWhat will you do?");
		System.out.println("A. Shoot it.");
		System.out.println("B. Grenade it.");
		System.out.println("C. Decapitate it.");
		System.out.println("D. Heal with Regular Potion.");
		System.out.println("E. Heal with Super Potion.");
		System.out.println("F. Reload.");
		System.out.println("Enter choice: ");	
	}
	
}
