package me14;


import java.util.Scanner;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;


public class Player extends GameObject {
	Scanner sc= new Scanner(System.in);
	String name;
	int hp;
	int bullets;
	int grenades;
	int rPotions;
	int sPotions;
	boolean alive;
	BufferedImage warrior;
	BufferedImage deadwarrior;
	
	Zombie z=new Zombie();
	int choice=0;
	
	public Player(){
		hp=100;
		bullets=6;
		grenades=10;
		rPotions=10;
		sPotions=3;
		alive=true;
		warrior=MarioWindow.getImage("p1.png");
		deadwarrior=MarioWindow.getImage("p2.png");
		
	}
	
	public void paint(Graphics2D g){ //Mario window is running independently
	
		Font text= new Font("Courier New",1,24);
		g.setFont(text);
		g.setColor(Color.WHITE);
		
		//HEALTH
		if (hp>=80) {
			g.setColor(Color.GREEN);	
			g.drawString("hp= " + hp,120,210);
			g.drawImage(warrior,100,300,null);
		} else if(hp>=40&&hp<80){
			g.setColor(Color.YELLOW);
			g.drawString("hp= " + hp,120,210);
			g.drawImage(warrior,100,300,null);
		} else if(hp<40&&hp>=1){
			g.setColor(Color.RED);
			g.drawString("hp= " + hp,120,210);
			g.drawImage(warrior,100,300,null);
		} else if (hp<=0){
			Font dead =new Font("Courier New",1,36);
			g.setFont(dead);
			g.setColor(Color.RED);
			g.drawString("YOU ARE DEAD!!", 500, 300);
			g.drawImage(deadwarrior, 100, 300, null);
		}
		Font status= new Font("Courier New",1,24);
		g.setFont(status);
		g.setColor(Color.WHITE);
		g.drawString("Bullets: " + bullets + "/6",120, 230);
		
		//GRENADES
		g.drawString("grenades: " + grenades + "/10", 120,250);	
		
		//RPOTION
		g.setColor(Color.MAGENTA);
		g.drawString("Regular Potions: " + rPotions + "/10", 120,270);	
		//SPOTION
		g.setColor(Color.PINK);
		g.drawString("Super Potions: " + sPotions + "/3", 120,290);	
		
		//ACTIONS
		g.setColor(Color.RED);
		if (choice==1){
			g.drawString("Bang!", 500, 300);
			
		} else if(choice==2){
			g.drawString("Fire in the hole!", 500, 300);
			
			
		} else if(choice==3){
			g.drawString("Heal! +10 hp",500,300);
			
		} else if (choice==4){
			
			g.drawString("Super Heal! +30 hp",500,300);
		} else if(choice==5){
			g.drawString("Reload!", 500, 300);
		}
		
	}
	

	public boolean shootZombie(){
		choice=1;
		if(bullets>=1){
			bullets=bullets-1;
			return true;	
		} else{
			return false;
		}

	}
	
	public boolean grenadeZombie(){
		choice=2;
		if(grenades>=1){
			grenades=grenades-1;
			return true;
		} else{
			return false;
		}
	}
	
	public boolean useRegularPotion(){
		choice=3;
		if(rPotions>=1){
			return true;
		} else{
			return false;
		}
		
	}
	public boolean useSuperPotion(){
		choice=4;
		if(sPotions>=1){ 
			return true;
		} else{
			return false;
		}
	}
	public void reload(){
		choice=5;
		bullets=6;
	}
	public void zombiefied(){
		alive=false;
	}
	public boolean isStillAlive(){
			return alive;
	}
	public void visualize(){
		System.out.print("[");
	    for(int i=0; i<=(hp/10)-1;i++ ){
            System.out.print("*");
           
        }
        for(int i=0; i<=10-(hp/10)-1;i++){
            System.out.print("-");
        }      
	}
	
}


