//package zombie;

import java.util.Scanner;
//import java.util.Random;

public class ZombieDemo {
	public static void main (String args[]) {
		System.out.println("Zombie [**********] 100 hp");
		System.out.println("What will you do? \n");
		
		System.out.println("A. Shoot it.");
		System.out.println("B. Grenade it.");
		System.out.println("C. Decapitate it.");
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Choice: ");
		String choice="";
		choice=sc.nextLine();
		System.out.println("Choice is " + choice);
		
		Zombie z = new Zombie();
		while(z.hp>0){
			if(choice.equalsIgnoreCase("a")){
				z.shootMe();
				System.out.println("You shoot him. It hits but zombie has " + z.hp + " hp left!");
				if(z.hp<=0){
					System.out.println("You killed the zombie!");
					break;
				} else{
					z.regenerate();
					System.out.println("Zombie recovered. It has " + z.hp + " hp left.");
					z.visualize();
					z.choices();
					choice=sc.nextLine();
					System.out.println("Choice is " + choice);
				}
			}
			else if(choice.equalsIgnoreCase("b")){
				System.out.println("You toss a grenade!");
				if (z.grenadeMe()==true){
					if(z.hp<=0){
						System.out.println("You killed the zombie!");
						break;
					}
					System.out.println("It hits, dealing 30 damage!");
					z.regenerate();
					System.out.println("Zombie recovered. It has " + z.hp + "left.\n");
					z.visualize();
				} else{
					z.regenerate();
					System.out.println("It missed!");
					System.out.println("Zombie recovered. It has " + z.hp + "left.");
					z.visualize();
				}
				
				z.choices();
				choice=sc.nextLine();
				System.out.println("Choice is " + choice);
			}
			else {
				if (z.decapitate()==true){
					System.out.println("You killed the zombie! Congratulations for saving mankind!");
				} else{
					System.out.println("Congratulations! You became a zombie!");
				}
			}
		}
		
	}
}
