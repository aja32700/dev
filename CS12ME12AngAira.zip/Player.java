package zombie;
import java.util.Scanner;

public class Player {
	Scanner sc= new Scanner(System.in);
	String name;
	int hp;
	int bullets;
	int grenades;
	int rPotions;
	int sPotions;
	boolean alive;
	Zombie z=new Zombie();
	
	public Player(){
		hp=100;
		bullets=6;
		grenades=10;
		rPotions=10;
		sPotions=3;
		alive=true;
		
	}
	
	public boolean shootZombie(){
		if(bullets>=1){
			bullets=bullets-1;
			return true;	
		} else{
			return false;
		}
	}
	
	public boolean grenadeZombie(){
		if(grenades>=1){
			grenades=grenades-1;
			return true;
		} else{
			return false;
		}
	}
	
	public boolean useRegularPotion(){
		if(rPotions>=1){
			return true;
		} else{
			return false;
		}
		
	}
	public boolean useSuperPotion(){
		if(sPotions>=1){ 
			return true;
		} else{
			return false;
		}
	}
	public void reload(){
		bullets=6;
	}
	public void zombiefied(){
		alive=false;
	}
	public boolean isStillAlive(){
			return alive;
	}
	public void visualize(){
		System.out.print("[");
	    for(int i=0; i<=(hp/10)-1;i++ ){
            System.out.print("*");
        }
        for(int i=0; i<=10-(hp/10)-1;i++){
            System.out.print("-");
        }      
	}
}
