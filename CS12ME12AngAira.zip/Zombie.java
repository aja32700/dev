package zombie;
import java.util.Random;

public class Zombie{
	int hp=100;
	Random r= new Random();
	
	public void visualize(){
		System.out.print("[");
		for(int i=0; i<=(hp/10)-1;i++ ){
			System.out.print("*");
		}
		for(int i=0; i<=10-(hp/10)-1;i++){
			System.out.print("-");
		}
		System.out.print("] Zombie hp: " + hp + "\n");
	}	
	
	public void shootMe(){
		hp=hp-10;		
	}
	public int regenerate(){
		int dmg=r.nextInt(20)+1;
		hp=hp+dmg;
		return dmg;
	}
	public boolean grenadeMe(){
		int miss=r.nextInt(100)+1;
		if(miss>20){
			hp=hp-30;
			return true;
		} else{
			return false;
		}
	}
	public boolean decapitate(){
		int miss=r.nextInt(100)+1;
		if(miss<50){
			return true;
		} else {
			return false;
		}
	}
	public void choices(){
		System.out.println("\nWhat will you do?");
		System.out.println("A. Shoot it.");
		System.out.println("B. Grenade it.");
		System.out.println("C. Decapitate it.");
		System.out.println("D. Heal with Regular Potion.");
		System.out.println("E. Heal with Super Potion.");
		System.out.println("F. Reload.");
		System.out.println("Enter choice: ");	
	}
	
}
