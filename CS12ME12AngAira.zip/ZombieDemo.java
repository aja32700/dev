package zombie;
import java.util.Scanner;
public class ZombieDemo {
	public static void main (String args[]) {
		Player p = new Player();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Name: ");
		String name="";
		name=sc.nextLine();
		System.out.println("Welcome " + name + "!");
		System.out.println("Zombie [**********] 100 hp");
		System.out.println(name + " [**********] 100 hp");
		System.out.println("What will you do?");
		System.out.println("A. Shoot it.");
		System.out.println("B. Grenade it.");
		System.out.println("C. Decapitate it.");
		System.out.println("D. Heal with Regular Potion.");
		System.out.println("E. Heal with Super Potion.");
		System.out.println("F. Reload.");
		System.out.println("Enter Choice: ");
		String choice="";
		choice=sc.nextLine();
		System.out.println("Choice is " + choice);
		Zombie z = new Zombie();
		while(z.hp>0||p.isStillAlive()==true){
			if(choice.equalsIgnoreCase("a")){
				if(z.hp<=0){
					System.out.println("You killed the zombie!");
					break;
				}
				else{
					if(p.shootZombie()==true){
						z.shootMe();
						System.out.println("You shoot him. It hits but zombie has " + z.hp + " hp left!");
					} else{
						System.out.println("You are out of bullets Reload now!");		
					}
					int regen=z.regenerate();
					System.out.println("Zombie gets mad and attacks you! Deals" + regen + " hp!");
					System.out.println("Zombie recovered " + regen + ". It has " + z.hp + " hp left.");
					z.visualize();
					p.hp=p.hp-regen;
					p.visualize();
					System.out.print("] " + name + " hp: " + p.hp + " Bullets: " + p.bullets + "/6 G: " + p.grenades + " RP: " + p.rPotions + " SP: " + p.sPotions + " Still Alive!"); 
					z.choices();
					choice=sc.nextLine();
					System.out.println("Choice is " + choice);
				}
			}
			else if(choice.equalsIgnoreCase("b")){
				System.out.println("You toss a grenade!");
				if(p.grenadeZombie()==true){
					if (z.grenadeMe()==true){
						if(z.hp<=0){
							System.out.println("You killed the zombie!");
							break;
						} else{
							System.out.println("It hits, dealing 30 damage!");
							System.out.println("Zombie recovered. It has " + z.hp + "left.\n");
							int regen= z.regenerate();
							System.out.println("Zombie gets mad and attacks you! Deals" + regen + " hp!");
							System.out.println("Zombie recovered " + regen + ". It has " + z.hp + " hp left.");
						}
					} else{
						int regen= z.regenerate();
						System.out.println("Zombie gets mad and attacks you! Deals" + regen + " hp!");
						System.out.println("Zombie recovered " + regen + ". It has " + z.hp + " hp left.");
						p.hp=p.hp-regen;
						System.out.println("It missed!");
						System.out.println("Zombie recovered. It has " + z.hp + "left.");
					}
				}
				z.visualize();
				p.visualize();
				System.out.print("] " + name + " hp: " + p.hp + " Bullets: " + p.bullets + "/6 G: " + p.grenades + " RP: " + p.rPotions + " SP: " + p.sPotions + " Still Alive!"); 
				z.choices();
				choice=sc.nextLine();
				System.out.println("Choice is " + choice);
			}
			else if(choice.equalsIgnoreCase("c")){
				if (z.decapitate()==true){
					System.out.println("You launched your final attack and killed the zombie! Congratulations for saving mankind!");
					break;
				} else{
					System.out.println("You ready your final attack but you got bitten by the zombie first. Congratulations! You became a zombie!");
					p.zombiefied();
					break;
				}
			}
			else if(choice.equalsIgnoreCase("d")){
				if(p.useRegularPotion()==true){
					p.hp=p.hp+10;
					p.rPotions=p.rPotions=1;
					if (p.hp>=100){
						p.hp=100;
					}
					System.out.println("You drank Regular Potion and recovered 10 hp!");
				} else{
					System.out.println("Uh oh you ran out of potions!");
				}
				int regen= z.regenerate();
				System.out.println("Zombie gets mad at waiting and attacks you! Deals" + regen + " hp!");
				System.out.println("Zombie recovered " + regen + ". It has " + z.hp + " hp left.");
				p.hp=p.hp-regen;
				z.visualize();
				p.visualize();
				System.out.print("] " + name + " hp: " + p.hp + " Bullets: " + p.bullets + "/6 G: " + p.grenades + " RP: " + p.rPotions + " SP: " + p.sPotions + " Still Alive!"); 
				z.choices();
				choice=sc.nextLine();
				System.out.println("Choice is " + choice);
			} else if(choice.equalsIgnoreCase("e")){
				if(p.useSuperPotion()==true){
					p.hp=p.hp+20;
					p.sPotions=p.sPotions-1;
					if (p.hp>=100){
						p.hp=100;
					}
					System.out.println("You drank Super Potion and recovered 20 hp!");
				} else{
					System.out.println("Uh oh you ran out of potions!");
				}
				int regen= z.regenerate();
				System.out.println("Zombie gets mad at waiting and attacks you! Deals" + regen + " hp!");
				System.out.println("Zombie recovered " + regen + ". It has " + z.hp + " hp left.");
				p.hp=p.hp-regen;
				z.visualize();
				p.visualize();
				System.out.print("] " + name + " hp: " + p.hp + " Bullets: " + p.bullets + "/6 G: " + p.grenades + " RP: " + p.rPotions + " SP: " + p.sPotions + " Still Alive!"); 
				z.choices();
				choice=sc.nextLine();
				System.out.println("Choice is " + choice);
			} else{
				p.reload();
				System.out.println("You reloaded your ammo back to full");
				int regen= z.regenerate();
				System.out.println("Zombie gets mad at waiting and attacks you! Deals" + regen + " hp!");
				System.out.println("Zombie recovered " + regen + ". It has " + z.hp + " hp left.");
				p.hp=p.hp-regen;
				z.visualize();
				p.visualize();
				System.out.print("] " + name + " hp: " + p.hp + " Bullets: " + p.bullets + "/6 G: " + p.grenades + " RP: " + p.rPotions + " SP: " + p.sPotions + " Still Alive!"); 
				z.choices();
				choice=sc.nextLine();
				System.out.println("Choice is " + choice);
			}
		}
	}
}