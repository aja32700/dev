package tv;
import java.util.Scanner;
public class TVDemo {
	public static void main (String arg[]){
		Tv t= new Tv();
		System.out.println("A.Increase Channel");
		System.out.println("B.Decrease Channel");
		System.out.println("C.Increase Volume");
		System.out.println("D.Decrease Volume");
		System.out.println("E.Display");
		System.out.println("F.Quit");
		Scanner sc= new Scanner(System.in);
		String choice="";
		choice =sc.nextLine();
		while(t.turnedOn==true || t.turnedOn==false){
			if(choice.equalsIgnoreCase("a")){
				t.increaseChannel();
				t.choice();
				choice =sc.nextLine();
			} else if(choice.equalsIgnoreCase("b")){
				t.decreaseChannel();
				t.choice();
				choice =sc.nextLine();
			} else if(choice.equalsIgnoreCase("c")){
				t.increaseVolume();
				t.choice();
				choice =sc.nextLine();
			} else if(choice.equalsIgnoreCase("d")){
				t.decreaseVolume();
				t.choice();
				choice =sc.nextLine();
			} else if(choice.equalsIgnoreCase("e")){
				t.display();
				if(t.ctr==0){
					System.out.println("Channel: " + t.channel + "\nVolume: " + t.volume);
				} else
					System.out.println("TV is turned off!");
				t.choice();
				choice =sc.nextLine();
			} else{
				break;
			}
		}
	}
}

