package tv;

public class Tv {
	int channel;
	int volume;
	boolean turnedOn;
	int ctr;
	public Tv(){
		channel=2;
		volume=0;
		turnedOn=true;
		ctr=0;		
	}
	public void increaseChannel(){
		if(turnedOn=true){
			channel=channel+1;
			if(channel==13){
				channel=2;
			} else{
				channel=channel+0;
			}
		}
	}
	public void decreaseChannel(){
		if(turnedOn=true){
			channel=channel-1;
			if(channel==2){
				channel=13;
			}
		} else{
			channel=channel+0;
		}
	}
	public void increaseVolume(){
		if(turnedOn=true){
			if(volume==11){
				volume=11;
			} else if(volume==0){
				volume=1;
				turnedOn=true;
			} else{
				volume=volume+1;
			}
		}
	}
	public void decreaseVolume(){
		if(turnedOn==true){
			if (volume==0){
				turnedOn=!true;
				volume=0;
			} else{
				volume=volume-1;
			}
		}
	}
	public void display(){
		if(turnedOn==true){
			ctr=0;
		} else{
			ctr=1;
		}
	}
	public void choice(){
		System.out.println("A.Increase Channel");
		System.out.println("B.Decrease Channel");
		System.out.println("C.Increase Volume");
		System.out.println("D.Decrease Volume");
		System.out.println("E.Display");
		System.out.println("F.Quit");
	}
}
